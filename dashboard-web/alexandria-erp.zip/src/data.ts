import { Product, Transaction, ArchivalLog } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "ELX-4091",
    name: "Aurelian Headset Gen 4",
    description: "Audio inmersivo de alta fidelidad con cancelación de ruido activa.",
    category: "Electrónica",
    price: 189.00,
    stock: 12,
    maxStock: 30,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBH67K9QVOvbVMl-rMoXfMiz50mE5xgJhfddLVppklUBfkCDZ66sadOxknMfXevldXxAzuPwZqx-Ny2T08gSmtwP4GUvIbGpVfojcdHvr_DtuSr5KcfsAJuCXPHHizbqrPd_ncwmxQP_pvQ5bfdtUJndjNzq9NaINqPnLphCnRLG1k-7ZTpksKGkp9uR-CP3UUUy616cL5xMQXeAta3Iiq0NIXqT4hKGLCEoHF4_29tz_2URpbdXUbdrb9G4DMfmAd6mso9cT02PT8",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuCG6iGN_Mpm6aCOaLJmRKLS-SLhuEyCeBF1uIyNhWLgt8H5QVKZQS87_0K0yvto3vXv73XYjF_JguAiRuGc8Pye8s89Dx8I7YMsX11NNoCcuBd825T0rO6kSrSHPesuPJ7zl76RHzWFv9OdEo4KIk3EMCi-Idc9wGcn0U4lOuwBUFHfYWEqjkYQgjkQG9fua6WkUd8Gid9KESpRWDaJIypE3FOaQUNRbTtDhXc-3-x-uNzDaLm_4VrD2hi-y_GpUOJJYRBCeeBuFAE",
    serial: "SN-A984-ZKL-2023"
  },
  {
    id: "ACC-1101",
    name: "Cronos Elite Watch",
    description: "Diseño atemporal con movimiento suizo y cristal de zafiro.",
    category: "Accesorios",
    price: 245.00,
    stock: 4,
    maxStock: 15,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDzGNM_PAXsc-j-MFwqJl1yiUzDumdC1q92xOxDzJmRdgMXkZTwiZKFj79jTN0wz9pXxtKBwJrZIINkPoqofH3ScuIfNZYDxdbXuyIhzJk3b8DGBSHY8hBd3rRuufSy7G9MBgOjH3HfceryxnSg0qGQDF8eNp7p4yjM6WN50ymf5FyIBTKU0IO1P8oyK07jN7_5qwi5bKzHxanhQ_Y-jX4WcQKQAaIUX3cso4XzwkXhikmEZWOboGLorv1lkV7u-k0qQMrC1O1D_6Y",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuB7789tGr5SeV3p49slo3wezlpOp-RvVvCFJ0-Rs819h4t3egAcN10p8vZjmzSIqJBJMywAG4ngjM8FNvMmqjW_3RA0USGxh4YNzfMG2Zt4cL42M0S4uhJpGGJa_MFfrYdaLtsy_xaJwLnyMPaLgRwgA7gioIwJ1tZi-FIKMEDPui4AwLcVdXuDjqqpwrw-hbByYSqE12RNgk1WeBPBf3icIsBWw3vS0112rzP54HfUH1NQKrJrwmSdat437FV3FrekppQvQeIAkCg",
    serial: "SN-K551-MNO-2024"
  },
  {
    id: "ACC-3022",
    name: "Lumina Instant Cam",
    description: "Captura momentos con un estilo retro y revelado inmediato.",
    category: "Accesorios",
    price: 79.99,
    stock: 2,
    maxStock: 8,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCH6BrNpXW_Sn_oCReQX0LRLKFsTSRzTavE8ufP_MsWiBLDn7KkKbNvN2gS2yKvU2poIJXlbaAmWslY9r62C0GQhQTGW8Q5qNKOp7IPenIpKtbdNoTAevYbUSSLty0Vfyilisj9eBrFhKrN2Ffo3a7Rxpsb_M5oGFohS_kSigupjosUjeEZb3OrwTBIkp4q4Hiu8e-hAaZk-wIb5iZInrq0BsbkoncEZA6PDJcDdv9pz5LWN4AyPJQnWQ_BGBZWje4eQtWX1RmvAIg",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuBLsVe3xzHhAOPUn0XuUlH9DmfeRbsUNACnIbOQ690yfBbpsaogaMTFUx3jSWIELlPc74k251Qj19wahfnowoAha2sNtJAQZyIgdlw9xy2LIsrktEjzfQdUQTFXZ9HRNGer-xycYr4Y4zj2jQm7tLVQFfAPoGtxLmw5Nk0_2ItNA3g3-dB-mxI_vLq8gtAjxEFkzEhIIB05px6-AyVlELVIQKxbAqNbghriyzCG9dZcwzcS565VPPv7hEqbarcuYxeB7yCP1gRdZNE",
    expiration: "24 OCT 2026"
  },
  {
    id: "ELX-5520",
    name: "Alexandria Pad Pro",
    description: "Productividad editorial con pantalla Retina de alta resolución.",
    category: "Electrónica",
    price: 512.00,
    stock: 22,
    maxStock: 50,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBJsxQzQ4wKt17SIU034dPnQe1EgNTZ7I-h1BEJBGRWQs3wXbbR0S2fDYPA8FFGEJjy3XWqJqAU1QA7peia6CR1HnmgnKh0vD2anqD3E7OoUK9jchac5ssK_Ttag-OaX4R_B0tds39QCyAH8VEPtJVN-FxVw3j4mkYQHgBeI3NYBltVcgpDLnDJ6_55eh2XrnywuHbYIY8RqPqCWuws30v74LgY7hnTWsalEC-16vq_Eh_lRvEIpkSHHH29e6SPhjI6NLk6_doseYU",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuBJsxQzQ4wKt17SIU034dPnQe1EgNTZ7I-h1BEJBGRWQs3wXbbR0S2fDYPA8FFGEJjy3XWqJqAU1QA7peia6CR1HnmgnKh0vD2anqD3E7OoUK9jchac5ssK_Ttag-OaX4R_B0tds39QCyAH8VEPtJVN-FxVw3j4mkYQHgBeI3NYBltVcgpDLnDJ6_55eh2XrnywuHbYIY8RqPqCWuws30v74LgY7hnTWsalEC-16vq_Eh_lRvEIpkSHHH29e6SPhjI6NLk6_doseYU",
    serial: "SN-P332-LMN-2024"
  },
  {
    id: "ELX-4092",
    name: "MacBook Pro M3 14\"",
    description: "Máxima potencia en Space Grey con chip M3, 512GB SSD y pantalla Liquid Retina XDR.",
    category: "Electrónica",
    price: 1499.00,
    stock: 128,
    maxStock: 300,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBJsxQzQ4wKt17SIU034dPnQe1EgNTZ7I-h1BEJBGRWQs3wXbbR0S2fDYPA8FFGEJjy3XWqJqAU1QA7peia6CR1HnmgnKh0vD2anqD3E7OoUK9jchac5ssK_Ttag-OaX4R_B0tds39QCyAH8VEPtJVN-FxVw3j4mkYQHgBeI3NYBltVcgpDLnDJ6_55eh2XrnywuHbYIY8RqPqCWuws30v74LgY7hnTWsalEC-16vq_Eh_lRvEIpkSHHH29e6SPhjI6NLk6_doseYU",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuBJsxQzQ4wKt17SIU034dPnQe1EgNTZ7I-h1BEJBGRWQs3wXbbR0S2fDYPA8FFGEJjy3XWqJqAU1QA7peia6CR1HnmgnKh0vD2anqD3E7OoUK9jchac5ssK_Ttag-OaX4R_B0tds39QCyAH8VEPtJVN-FxVw3j4mkYQHgBeI3NYBltVcgpDLnDJ6_55eh2XrnywuHbYIY8RqPqCWuws30v74LgY7hnTWsalEC-16vq_Eh_lRvEIpkSHHH29e6SPhjI6NLk6_doseYU",
    serial: "SN-A984-ZKL-2023"
  },
  {
    id: "SPM-1102",
    name: "Leche Entera Premium 1L",
    description: "Leche entera fresca fluida pasteurizada. Pack x12 Unidades.",
    category: "Supermercado",
    price: 1.99,
    stock: 14,
    maxStock: 120,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCH6BrNpXW_Sn_oCReQX0LRLKFsTSRzTavE8ufP_MsWiBLDn7KkKbNvN2gS2yKvU2poIJXlbaAmWslY9r62C0GQhQTGW8Q5qNKOp7IPenIpKtbdNoTAevYbUSSLty0Vfyilisj9eBrFhKrN2Ffo3a7Rxpsb_M5oGFohS_kSigupjosUjeEZb3OrwTBIkp4q4Hiu8e-hAaZk-wIb5iZInrq0BsbkoncEZA6PDJcDdv9pz5LWN4AyPJQnWQ_BGBZWje4eQtWX1RmvAIg",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuBLsVe3xzHhAOPUn0XuUlH9DmfeRbsUNACnIbOQ690yfBbpsaogaMTFUx3jSWIELlPc74k251Qj19wahfnowoAha2sNtJAQZyIgdlw9xy2LIsrktEjzfQdUQTFXZ9HRNGer-xycYr4Y4zj2jQm7tLVQFfAPoGtxLmw5Nk0_2ItNA4g3-dB-mxI_vLq8gtAjxEFkzEhIIB05px6-AyVlELVIQKxbAqNbghriyzCG9dZcwzcS565VPPv7hEqbarcuYxeB7yCP1gRdZNE",
    expiration: "24 OCT 2024"
  },
  {
    id: "ELX-5521",
    name: "Audífonos Studio Pro",
    description: "Noise cancelling avanzado, color blanco, sonido espacial.",
    category: "Electrónica",
    price: 199.99,
    stock: 422,
    maxStock: 500,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBH67K9QVOvbVMl-rMoXfMiz50mE5xgJhfddLVppklUBfkCDZ66sadOxknMfXevldXxAzuPwZqx-Ny2T08gSmtwP4GUvIbGpVfojcdHvr_DtuSr5KcfsAJuCXPHHizbqrPd_ncwmxQP_pvQ5bfdtUJndjNzq9NaINqPnLphCnRLG1k-7ZTpksKGkp9uR-CP3UUUy616cL5xMQXeAta3Iiq0NIXqT4hKGLCEoHF4_29tz_2URpbdXUbdrb9G4DMfmAd6mso9cT02PT8",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuCG6iGN_Mpm6aCOaLJmRKLS-SLhuEyCeBF1uIyNhWLgt8H5QVKZQS87_0K0yvto3vXv73XYjF_JguAiRuGc8Pye8s89Dx8I7YMsX11NNoCcuBd825T0rO6kSrSHPesuPJ7zl76RHzWFv9OdEo4KIk3EMCi-Idc9wGcn0U4lOuwBUFHfYWEqjkYQgjkQG9fua6WkUd8Gid9KESpRWDaJIypE3FOaQUNRbTtDhXc-3-x-uNzDaLm_4VrD2hi-y_GpUOJJYRBCeeBuFAE",
    serial: "SN-P332-LMN-2024"
  },
  {
    id: "SPM-8890",
    name: "Aceite de Oliva Virgen 500ml",
    description: "Aceite de oliva virgen extra obtenido directamente de aceitunas. Origen Andalucía.",
    category: "Supermercado",
    price: 8.99,
    stock: 210,
    maxStock: 400,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCH6BrNpXW_Sn_oCReQX0LRLKFsTSRzTavE8ufP_MsWiBLDn7KkKbNvN2gS2yKvU2poIJXlbaAmWslY9r62C0GQhQTGW8Q5qNKOp7IPenIpKtbdNoTAevYbUSSLty0Vfyilisj9eBrFhKrN2Ffo3a7Rxpsb_M5oGFohS_kSigupjosUjeEZb3OrwTBIkp4q4Hiu8e-hAaZk-wIb5iZInrq0BsbkoncEZA6PDJcDdv9pz5LWN4AyPJQnWQ_BGBZWje4eQtWX1RmvAIg",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuCH6BrNpXW_Sn_oCReQX0LRLKFsTSRzTavE8ufP_MsWiBLDn7KkKbNvN2gS2yKvU2poIJXlbaAmWslY9r62C0GQhQTGW8Q5qNKOp7IPenIpKtbdNoTAevYbUSSLty0Vfyilisj9eBrFhKrN2Ffo3a7Rxpsb_M5oGFohS_kSigupjosUjeEZb3OrwTBIkp4q4Hiu8e-hAaZk-wIb5iZInrq0BsbkoncEZA6PDJcDdv9pz5LWN4AyPJQnWQ_BGBZWje4eQtWX1RmvAIg",
    expiration: "12 ENE 2026"
  },
  {
    id: "HOG-2015",
    name: "Lámpara Minimalista Aura",
    description: "Lámpara de mesa con dimmer táctil y luz cálida relajante.",
    category: "Hogar",
    price: 49.99,
    stock: 18,
    maxStock: 40,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDzGNM_PAXsc-j-MFwqJl1yiUzDumdC1q92xOxDzJmRdgMXkZTwiZKFj79jTN0wz9pXxtKBwJrZIINkPoqofH3ScuIfNZYDxdbXuyIhzJk3b8DGBSHY8hBd3rRuufSy7G9MBgOjH3HfceryxnSg0qGQDF8eNp7p4yjM6WN50ymf5FyIBTKU0IO1P8oyK07jN7_5qwi5bKzHxanhQ_Y-jX4WcQKQAaIUX3cso4XzwkXhikmEZWOboGLorv1lkV7u-k0qQMrC1O1D_6Y",
    thumbnail: "https://lh3.googleusercontent.com/aida-public/AB6AXuB7789tGr5SeV3p49slo3wezlpOp-RvVvCFJ0-Rs819h4t3egAcN10p8vZjmzSIqJBJMywAG4ngjM8FNvMmqjW_3RA0USGxh4YNzfMG2Zt4cL42M0S4uhJpGGJa_MFfrYdaLtsy_xaJwLnyMPaLgRwgA7gioIwJ1tZi-FIKMEDPui4AwLcVdXuDjqqpwrw-hbByYSqE12RNgk1WeBPBf3icIsBWw3vS0112rzP54HfUH1NQKrJrwmSdat437FV3FrekppQvQeIAkCg",
    serial: "SN-L908-AURA-2025"
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: "TX-8821",
    client: "Factoría Textil",
    company: "Inditex Group",
    branch: "Madrid Main",
    amount: 124500.00,
    method: "Transferencia",
    status: "Completado",
    date: "2026-06-11T14:30:00Z"
  },
  {
    id: "TX-8822",
    client: "Suministros Globales",
    company: "Amazon Corporate",
    branch: "Barcelona Port",
    amount: 89200.00,
    method: "Crédito",
    status: "Pendiente",
    date: "2026-06-10T09:15:00Z"
  },
  {
    id: "TX-8823",
    client: "Fondo Consolidado",
    company: "Santander Int.",
    branch: "Valencia HQ",
    amount: 210000.00,
    method: "Transferencia",
    status: "Completado",
    date: "2026-06-09T17:45:00Z"
  },
  {
    id: "TX-8824",
    client: "Embarques S.A.",
    company: "Global Logistics",
    branch: "Sevilla Hub",
    amount: 45600.00,
    method: "Efectivo",
    status: "Fallido",
    date: "2026-06-08T11:20:00Z"
  }
];

export const INITIAL_LOGS: ArchivalLog[] = [
  {
    id: "LOG-001",
    type: "recepcion",
    message: "Recepción: 450 Unidades de Electrónica",
    details: "Almacén Central - Auditoría física exitosa",
    amount: 89200.00,
    date: "2026-06-11T20:24:00Z"
  },
  {
    id: "LOG-002",
    type: "despacho",
    message: "Despacho: Suministros Perecederos",
    details: "Sucursal Norte - Merma cero registrada",
    amount: -12450.00,
    date: "2026-06-11T17:15:00Z"
  },
  {
    id: "LOG-003",
    type: "auditoria",
    message: "Auditoría de Almacén Q3 Completa",
    details: "Corporativo - Verificación de valorización de activos",
    date: "2026-06-10T12:00:00Z"
  }
];
