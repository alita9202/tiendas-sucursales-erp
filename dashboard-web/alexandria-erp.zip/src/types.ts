export interface Product {
  id: string;
  name: string;
  description: string;
  category: 'Electrónica' | 'Accesorios' | 'Hogar' | 'Supermercado';
  price: number;
  stock: number;
  maxStock: number;
  image: string;
  thumbnail: string;
  serial?: string;
  expiration?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Transaction {
  id: string;
  client: string;
  company: string;
  branch: string;
  amount: number;
  method: 'Efectivo' | 'Tarjeta' | 'QR' | 'Crédito' | 'Transferencia';
  status: 'Completado' | 'Pendiente' | 'Fallido';
  date: string;
}

export interface ArchivalLog {
  id: string;
  type: 'recepcion' | 'despacho' | 'auditoria' | 'venta';
  message: string;
  details: string;
  amount?: number;
  date: string;
}
